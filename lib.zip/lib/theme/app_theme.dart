import 'package:flutter/material.dart';

class AppColors {
  static const Color primaryDark = Color(0xFF0B132B); // Dark navy
  static const Color primaryNavy = Color(0xFF0F172A);
  static const Color accentGold = Color(0xFFB8860B); // Gold accents/tags
  static const Color backgroundLight = Color(0xFFF7FAFC); // Main light background
  static const Color inputBackground = Color(0xFFF1F5F9); // Filled input background
  static const Color cardBackground = Colors.white;
  static const Color borderLight = Color(0xFFE2E8F0);
  static const Color textPrimary = Color(0xFF0F172A);
  static const Color textSecondary = Color(0xFF64748B);
  static const Color starGold = Color(0xFFEAB308);
  static const Color badgeYellow = Color(0xFFEAB308);
  static const Color badgeYellowBg = Color(0xFFFEF08A);
  static const Color tealText = Color(0xFF0D9488);
}

class AppTheme {
  static ThemeData get lightTheme {
    return ThemeData(
      scaffoldBackgroundColor: AppColors.backgroundLight,
      colorScheme: ColorScheme.fromSeed(
        seedColor: AppColors.primaryDark,
        primary: AppColors.primaryDark,
        surface: AppColors.backgroundLight,
      ),
      fontFamily: 'sans-serif',
      useMaterial3: true,
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.backgroundLight,
        elevation: 0,
        scrolledUnderElevation: 0,
        iconTheme: IconThemeData(color: AppColors.textPrimary),
        titleTextStyle: TextStyle(
          color: AppColors.textPrimary,
          fontSize: 22,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}
