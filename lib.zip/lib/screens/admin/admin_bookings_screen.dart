import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';

class AdminBookingModel {
  String id;
  String ref;
  String guestName;
  String guestType;
  String hotelName;
  String dates;
  String amount;
  String status; // 'CONFIRMED', 'PENDING', 'CANCELLED'

  AdminBookingModel({
    required this.id,
    required this.ref,
    required this.guestName,
    required this.guestType,
    required this.hotelName,
    required this.dates,
    required this.amount,
    required this.status,
  });
}

class AdminBookingsScreen extends StatefulWidget {
  const AdminBookingsScreen({super.key});

  @override
  State<AdminBookingsScreen> createState() => _AdminBookingsScreenState();
}

class _AdminBookingsScreenState extends State<AdminBookingsScreen> {
  int _selectedFilter = 0; // 0: All, 1: Confirmed, 2: Pending

  final List<AdminBookingModel> _bookings = [
    AdminBookingModel(
      id: '#BK-9021',
      ref: 'REF: YAT-AM-01',
      guestName: 'Julian Casablancas',
      guestType: 'VIP Member',
      hotelName: 'Aman-i-Khás',
      dates: 'Oct 14 - 18, 2024',
      amount: '₹4,250.00',
      status: 'CONFIRMED',
    ),
    AdminBookingModel(
      id: '#BK-9022',
      ref: 'REF: YAT-AM-02',
      guestName: 'Sarah Jenkins',
      guestType: 'Regular Guest',
      hotelName: 'Le Parisien Luxe',
      dates: 'Oct 24 - 28, 2024',
      amount: '₹1,840.00',
      status: 'PENDING',
    ),
    AdminBookingModel(
      id: '#BK-9023',
      ref: 'REF: YAT-AM-03',
      guestName: 'Alex Rivera',
      guestType: 'Premium Member',
      hotelName: 'Azure Beach Resort',
      dates: 'Nov 04 - 09, 2024',
      amount: '₹6,200.00',
      status: 'CONFIRMED',
    ),
    AdminBookingModel(
      id: '#BK-9024',
      ref: 'REF: YAT-AM-04',
      guestName: 'Elena Rostova',
      guestType: 'VIP Member',
      hotelName: 'Summit Spire Lodge',
      dates: 'Dec 10 - 14, 2024',
      amount: '₹3,200.00',
      status: 'CANCELLED',
    ),
  ];

  List<AdminBookingModel> get _filteredList {
    if (_selectedFilter == 1) {
      return _bookings.where((b) => b.status == 'CONFIRMED').toList();
    } else if (_selectedFilter == 2) {
      return _bookings.where((b) => b.status == 'PENDING').toList();
    }
    return _bookings;
  }

  void _openNewBookingSheet() {
    final amountCtrl = TextEditingController(text: '3500.00');
    final guestCtrl = TextEditingController();
    final datesCtrl = TextEditingController(text: 'Oct 24 - 28, 2024');
    String selectedHotel = 'Le Parisien Luxe';
    String selectedStatus = 'CONFIRMED';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Container(
              padding: EdgeInsets.only(
                top: 20,
                left: 20,
                right: 20,
                bottom: MediaQuery.of(context).viewInsets.bottom + 20,
              ),
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: Colors.grey.shade300,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'Add New Reservation',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: AppColors.primaryDark,
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Text('Guest Name', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: AppColors.textSecondary)),
                  const SizedBox(height: 6),
                  TextField(
                    controller: guestCtrl,
                    decoration: InputDecoration(
                      hintText: 'e.g. Julian Casablancas',
                      filled: true,
                      fillColor: AppColors.inputBackground,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                    ),
                  ),
                  const SizedBox(height: 14),
                  const Text('Hotel', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: AppColors.textSecondary)),
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    decoration: BoxDecoration(
                      color: AppColors.inputBackground,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        value: selectedHotel,
                        isExpanded: true,
                        items: ['Aman-i-Khás', 'Le Parisien Luxe', 'Azure Beach Resort', 'Summit Spire Lodge'].map((h) {
                          return DropdownMenuItem(value: h, child: Text(h, style: const TextStyle(fontSize: 13)));
                        }).toList(),
                        onChanged: (val) {
                          if (val != null) setModalState(() => selectedHotel = val);
                        },
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Amount (₹)', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: AppColors.textSecondary)),
                            const SizedBox(height: 6),
                            TextField(
                              controller: amountCtrl,
                              keyboardType: TextInputType.number,
                              decoration: InputDecoration(
                                filled: true,
                                fillColor: AppColors.inputBackground,
                                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
                                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Dates', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: AppColors.textSecondary)),
                            const SizedBox(height: 6),
                            TextField(
                              controller: datesCtrl,
                              decoration: InputDecoration(
                                filled: true,
                                fillColor: AppColors.inputBackground,
                                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
                                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  const Text('Status', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: AppColors.textSecondary)),
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    decoration: BoxDecoration(
                      color: AppColors.inputBackground,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        value: selectedStatus,
                        isExpanded: true,
                        items: ['CONFIRMED', 'PENDING', 'CANCELLED'].map((s) {
                          return DropdownMenuItem(
                            value: s,
                            child: Text(s, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                          );
                        }).toList(),
                        onChanged: (val) {
                          if (val != null) setModalState(() => selectedStatus = val);
                        },
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: ElevatedButton(
                      onPressed: () {
                        if (guestCtrl.text.trim().isEmpty) return;
                        setState(() {
                          _bookings.insert(
                            0,
                            AdminBookingModel(
                              id: '#BK-${9025 + _bookings.length}',
                              ref: 'REF: YAT-AM-0${_bookings.length + 1}',
                              guestName: guestCtrl.text.trim(),
                              guestType: 'Guest',
                              hotelName: selectedHotel,
                              dates: datesCtrl.text.trim(),
                              amount: '₹${amountCtrl.text.trim()}',
                              status: selectedStatus,
                            ),
                          );
                        });
                        Navigator.pop(context);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primaryNavy,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: const Text('CREATE BOOKING', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 12.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Metric Card 1: TOTAL REVENUE
              _buildMetricSummaryCard(
                label: 'TOTAL REVENUE',
                value: '₹124,500.00',
                watermarkIcon: Icons.payments_outlined,
              ),
              const SizedBox(height: 14),

              // Metric Card 2: NEW RESERVATIONS
              _buildMetricSummaryCard(
                label: 'NEW RESERVATIONS',
                value: '${80 + _bookings.length}',
                subtitleRow: const Row(
                  children: [
                    Icon(Icons.calendar_month_outlined,
                        size: 14, color: AppColors.textSecondary),
                    SizedBox(width: 4),
                    Text(
                      '24 pending approval',
                      style: TextStyle(
                        fontSize: 13,
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ],
                ),
                watermarkIcon: Icons.calendar_today_outlined,
              ),
              const SizedBox(height: 14),

              // Metric Card 3: OCCUPANCY RATE
              _buildMetricSummaryCard(
                label: 'OCCUPANCY RATE',
                value: '92%',
                subtitleRow: const Row(
                  children: [
                    Icon(Icons.hotel_outlined,
                        size: 14, color: AppColors.accentGold),
                    SizedBox(width: 4),
                    Text(
                      'Peak season active',
                      style: TextStyle(
                        fontSize: 13,
                        color: AppColors.accentGold,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
                watermarkIcon: Icons.domain_outlined,
              ),
              const SizedBox(height: 24),

              // Filter Pills Row & + New Booking Button
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF1F5F9),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      children: [
                        _buildFilterPill('All', 0),
                        _buildFilterPill('Confirmed', 1),
                        _buildFilterPill('Pending', 2),
                      ],
                    ),
                  ),
                  ElevatedButton.icon(
                    onPressed: _openNewBookingSheet,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primaryNavy,
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 10),
                    ),
                    icon: const Icon(Icons.add, color: Colors.white, size: 16),
                    label: const Text(
                      'New Booking',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),

              // Full Horizontal Sliding Table Card for Bookings
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.borderLight),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.02),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                clipBehavior: Clip.antiAlias,
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: SizedBox(
                    width: 680, // Generous 680px table width for all columns
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Table Header Bar
                        Container(
                          color: const Color(0xFFF1F5F9),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 14),
                          child: Row(
                            children: const [
                              SizedBox(
                                width: 110,
                                child: Text('BOOKING ID',
                                    style: TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.bold,
                                        color: AppColors.textSecondary,
                                        letterSpacing: 0.8)),
                              ),
                              SizedBox(
                                width: 140,
                                child: Text('GUEST',
                                    style: TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.bold,
                                        color: AppColors.textSecondary,
                                        letterSpacing: 0.8)),
                              ),
                              SizedBox(
                                width: 130,
                                child: Text('HOTEL',
                                    style: TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.bold,
                                        color: AppColors.textSecondary,
                                        letterSpacing: 0.8)),
                              ),
                              SizedBox(
                                width: 100,
                                child: Text('AMOUNT',
                                    style: TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.bold,
                                        color: AppColors.textSecondary,
                                        letterSpacing: 0.8)),
                              ),
                              SizedBox(
                                width: 120,
                                child: Text('STATUS',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.bold,
                                        color: AppColors.textSecondary,
                                        letterSpacing: 0.8)),
                              ),
                              SizedBox(
                                width: 60,
                                child: Text('ACTIONS',
                                    textAlign: TextAlign.right,
                                    style: TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.bold,
                                        color: AppColors.textSecondary,
                                        letterSpacing: 0.8)),
                              ),
                            ],
                          ),
                        ),
                        const Divider(height: 1, color: AppColors.borderLight),

                        // Booking Item Rows
                        ListView.separated(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: _filteredList.length,
                          separatorBuilder: (_, _) =>
                              const Divider(height: 1, color: AppColors.borderLight),
                          itemBuilder: (context, index) {
                            final booking = _filteredList[index];
                            return _buildFullBookingRowItem(booking);
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMetricSummaryCard({
    required String label,
    required String value,
    Widget? subtitleRow,
    required IconData watermarkIcon,
  }) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.borderLight),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.02),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textSecondary,
                  letterSpacing: 1.0,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: AppColors.primaryDark,
                ),
              ),
              if (subtitleRow != null) ...[
                const SizedBox(height: 8),
                subtitleRow,
              ],
            ],
          ),
          Icon(
            watermarkIcon,
            size: 42,
            color: AppColors.borderLight,
          ),
        ],
      ),
    );
  }

  Widget _buildFilterPill(String label, int index) {
    final bool isSelected = _selectedFilter == index;

    return GestureDetector(
      onTap: () => setState(() => _selectedFilter = index),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? AppColors.primaryNavy : Colors.transparent,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 12,
            fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
            color: isSelected ? Colors.white : AppColors.textSecondary,
          ),
        ),
      ),
    );
  }

  Widget _buildFullBookingRowItem(AdminBookingModel booking) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 16.0),
      child: Row(
        children: [
          // BOOKING ID (110px)
          SizedBox(
            width: 110,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  booking.id,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: AppColors.primaryDark,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  booking.ref,
                  style: const TextStyle(
                    fontSize: 10,
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),

          // GUEST (140px)
          SizedBox(
            width: 140,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  booking.guestName,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  booking.guestType,
                  style: const TextStyle(
                    fontSize: 11,
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),

          // HOTEL (130px)
          SizedBox(
            width: 130,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  booking.hotelName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  booking.dates,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 10,
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),

          // AMOUNT (100px)
          SizedBox(
            width: 100,
            child: Text(
              booking.amount,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: AppColors.primaryDark,
              ),
            ),
          ),

          // STATUS (120px)
          SizedBox(
            width: 120,
            child: Center(
              child: _buildStatusPill(booking.status),
            ),
          ),

          // ACTIONS (60px)
          SizedBox(
            width: 60,
            child: Align(
              alignment: Alignment.centerRight,
              child: PopupMenuButton<String>(
                icon: const Icon(
                  Icons.more_vert,
                  color: AppColors.textPrimary,
                  size: 20,
                ),
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
                onSelected: (action) {
                  if (action == 'confirm') {
                    setState(() => booking.status = 'CONFIRMED');
                  } else if (action == 'pending') {
                    setState(() => booking.status = 'PENDING');
                  } else if (action == 'cancel') {
                    setState(() => booking.status = 'CANCELLED');
                  } else if (action == 'delete') {
                    setState(() {
                      _bookings.removeWhere((b) => b.id == booking.id);
                    });
                  }
                },
                itemBuilder: (context) => [
                  const PopupMenuItem(
                    value: 'confirm',
                    child: Text('Mark CONFIRMED'),
                  ),
                  const PopupMenuItem(
                    value: 'pending',
                    child: Text('Mark PENDING'),
                  ),
                  const PopupMenuItem(
                    value: 'cancel',
                    child: Text('Mark CANCELLED'),
                  ),
                  const PopupMenuDivider(),
                  const PopupMenuItem(
                    value: 'delete',
                    child: Text('Delete Reservation', style: TextStyle(color: Colors.red)),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusPill(String status) {
    Color bg;
    Color text;

    if (status == 'CONFIRMED') {
      bg = const Color(0xFFEAFBF8);
      text = const Color(0xFF0F766E);
    } else if (status == 'PENDING') {
      bg = const Color(0xFFFFF7E6);
      text = const Color(0xFFB45309);
    } else {
      bg = const Color(0xFFFEF2F2);
      text = const Color(0xFFB91C1C);
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Text(
        status,
        style: TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.bold,
          color: text,
          letterSpacing: 0.5,
        ),
      ),
    );
  }
}
