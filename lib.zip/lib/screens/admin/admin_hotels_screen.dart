import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import 'admin_inventory_screen.dart';

class AdminHotelsScreen extends StatelessWidget {
  const AdminHotelsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 12.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Title
              const Text(
                'Master of\nHotels',
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: AppColors.primaryDark,
                  height: 1.15,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'A curated overview of the global hospitality network. Monitor performance, manage listings, and optimize occupancy with discerning precision.',
                style: TextStyle(
                  fontSize: 14,
                  color: AppColors.textSecondary,
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 24),

              // Hotel Card 1: The Azure Retreat
              _buildHotelCard(
                context,
                imageUrl:
                    'https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?q=80&w=800&auto=format&fit=crop',
                statusText: 'LIVE',
                statusBgColor: const Color(0xFFD1FAE5),
                statusTextColor: const Color(0xFF065F46),
                hotelId: 'ID: YTR-8821',
                title: 'The Azure Retreat',
                actionIcon: Icons.star_border,
                occupancy: '88%',
              ),
              const SizedBox(height: 20),

              // Hotel Card 2: Summit Spire Lodge
              _buildHotelCard(
                context,
                imageUrl:
                    'https://images.unsplash.com/photo-1518780664697-55e3ad937233?q=80&w=800&auto=format&fit=crop',
                statusText: 'PENDING',
                statusBgColor: const Color(0xFFFEF3C7),
                statusTextColor: const Color(0xFF92400E),
                hotelId: 'ID: YTR-1042',
                title: 'Summit Spire Lodge',
                actionIcon: Icons.more_horiz,
                occupancy: '12%',
              ),
              const SizedBox(height: 20),

              // Hotel Card 3: Oasis Obscura
              _buildHotelCard(
                context,
                imageUrl:
                    'https://images.unsplash.com/photo-1514282401047-d79a71a590e8?q=80&w=800&auto=format&fit=crop',
                statusText: 'HIDDEN',
                statusBgColor: const Color(0xFFE2E8F0),
                statusTextColor: const Color(0xFF475569),
                hotelId: 'ID: YTR-4559',
                title: 'Oasis Obscura',
                actionIcon: Icons.visibility_off_outlined,
                occupancy: '45%',
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHotelCard(
    BuildContext context, {
    required String imageUrl,
    required String statusText,
    required Color statusBgColor,
    required Color statusTextColor,
    required String hotelId,
    required String title,
    required IconData actionIcon,
    required String occupancy,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.borderLight),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.03),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Image + Status Badge
          Stack(
            children: [
              Image.network(
                imageUrl,
                height: 190,
                width: double.infinity,
                fit: BoxFit.cover,
                errorBuilder: (_, _, _) => Container(
                  height: 190,
                  color: Colors.grey.shade300,
                ),
              ),
              Positioned(
                top: 12,
                right: 12,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: statusBgColor,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    statusText,
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      color: statusTextColor,
                    ),
                  ),
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ID and Action Icon
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      hotelId,
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: AppColors.textSecondary,
                      ),
                    ),
                    Icon(actionIcon, color: AppColors.textSecondary, size: 20),
                  ],
                ),
                const SizedBox(height: 4),
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const AdminInventoryScreen(),
                      ),
                    );
                  },
                  child: Text(
                    title,
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: AppColors.primaryDark,
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                const Divider(height: 1, color: AppColors.borderLight),
                const SizedBox(height: 14),

                // Occupancy Row
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'OCCUPANCY',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                        color: AppColors.textSecondary,
                        letterSpacing: 1.0,
                      ),
                    ),
                    Text(
                      occupancy,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: AppColors.primaryDark,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
