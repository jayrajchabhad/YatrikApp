import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import 'admin_hotels_screen.dart';

class BookingModel {
  String id;
  String guestName;
  String guestEmail;
  String hotelName;
  String roomType;
  String dates;
  String status; // 'Confirmed', 'Pending', 'Cancelled'
  double amount;

  BookingModel({
    required this.id,
    required this.guestName,
    required this.guestEmail,
    required this.hotelName,
    required this.roomType,
    required this.dates,
    required this.status,
    required this.amount,
  });
}

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key});

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  final List<BookingModel> _allBookings = [
    BookingModel(
      id: '#BK10124',
      guestName: 'Alex Rivera',
      guestEmail: 'alex.rivera@example.com',
      hotelName: 'Le Parisien Luxe',
      roomType: 'Superior Suite',
      dates: 'Oct 12-15, 2023',
      status: 'Confirmed',
      amount: 4500,
    ),
    BookingModel(
      id: '#BK10123',
      guestName: 'Sarah Jenkins',
      guestEmail: 'sarah.j@example.com',
      hotelName: 'Azure Beach Resort',
      roomType: 'Deluxe Ocean View',
      dates: 'Oct 14-19, 2023',
      status: 'Pending',
      amount: 6200,
    ),
    BookingModel(
      id: '#BK10122',
      guestName: 'Julian Casablancas',
      guestEmail: 'julian.c@example.com',
      hotelName: 'The Azure Retreat',
      roomType: 'Royal Presidential Suite',
      dates: 'Nov 02-06, 2023',
      status: 'Confirmed',
      amount: 8800,
    ),
    BookingModel(
      id: '#BK10121',
      guestName: 'Elena Rostova',
      guestEmail: 'elena.r@example.com',
      hotelName: 'Summit Spire Lodge',
      roomType: 'Alpine Glass Chalet',
      dates: 'Dec 10-14, 2023',
      status: 'Cancelled',
      amount: 3200,
    ),
  ];

  String _filterStatus = 'All'; // 'All', 'Confirmed', 'Pending', 'Cancelled'

  List<BookingModel> get _filteredBookings {
    if (_filterStatus == 'All') return _allBookings;
    return _allBookings.where((b) => b.status == _filterStatus).toList();
  }

  // Calendar Date Range Picker
  Future<void> _selectDateRange(
      BuildContext context, TextEditingController controller) async {
    final DateTimeRange? picked = await showDateRangePicker(
      context: context,
      initialDateRange: DateTimeRange(
        start: DateTime.now(),
        end: DateTime.now().add(const Duration(days: 3)),
      ),
      firstDate: DateTime(2022),
      lastDate: DateTime(2028),
      builder: (context, child) {
        return Theme(
          data: ThemeData.light().copyWith(
            colorScheme: const ColorScheme.light(
              primary: AppColors.primaryNavy,
              onPrimary: Colors.white,
              surface: Colors.white,
              onSurface: AppColors.textPrimary,
            ),
          ),
          child: child!,
        );
      },
    );

    if (picked != null) {
      final months = [
        'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
      ];
      final start = picked.start;
      final end = picked.end;

      String formatted;
      if (start.month == end.month && start.year == end.year) {
        formatted = '${months[start.month - 1]} ${start.day}-${end.day}, ${start.year}';
      } else {
        formatted = '${months[start.month - 1]} ${start.day} - ${months[end.month - 1]} ${end.day}, ${end.year}';
      }
      controller.text = formatted;
    }
  }

  // Show New Booking Sheet
  void _openNewBookingForm() {
    final nameCtrl = TextEditingController();
    final emailCtrl = TextEditingController();
    final amountCtrl = TextEditingController(text: '3500');
    final datesCtrl = TextEditingController(text: 'Oct 24-28, 2023');

    String selectedHotel = 'Le Parisien Luxe';
    String selectedRoom = 'Standard King';
    String selectedStatus = 'Confirmed';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Container(
              padding: EdgeInsets.only(
                top: 20,
                left: 20,
                right: 20,
                bottom: MediaQuery.of(context).viewInsets.bottom + 20,
              ),
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
              ),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Container(
                        width: 40,
                        height: 4,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade300,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Create New Booking',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: AppColors.primaryDark,
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.close),
                          onPressed: () => Navigator.pop(context),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),

                    // Guest Name
                    _buildFormLabel('Guest Full Name'),
                    const SizedBox(height: 6),
                    _buildFormField(nameCtrl, hint: 'e.g. John Doe'),
                    const SizedBox(height: 14),

                    // Email Address
                    _buildFormLabel('Guest Email'),
                    const SizedBox(height: 6),
                    _buildFormField(emailCtrl, hint: 'e.g. john@example.com'),
                    const SizedBox(height: 14),

                    // Hotel Selection Dropdown
                    _buildFormLabel('Select Hotel'),
                    const SizedBox(height: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                      decoration: BoxDecoration(
                        color: AppColors.inputBackground,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          value: selectedHotel,
                          isExpanded: true,
                          items: [
                            'Le Parisien Luxe',
                            'Azure Beach Resort',
                            'The Azure Retreat',
                            'Summit Spire Lodge',
                            'Oasis Obscura',
                          ].map((h) {
                            return DropdownMenuItem(
                              value: h,
                              child: Text(h, style: const TextStyle(fontSize: 14)),
                            );
                          }).toList(),
                          onChanged: (val) {
                            if (val != null) setModalState(() => selectedHotel = val);
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),

                    // Room & Dates Row
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _buildFormLabel('Room Type'),
                              const SizedBox(height: 6),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 12),
                                decoration: BoxDecoration(
                                  color: AppColors.inputBackground,
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: DropdownButtonHideUnderline(
                                  child: DropdownButton<String>(
                                    value: selectedRoom,
                                    isExpanded: true,
                                    items: [
                                      'Standard King',
                                      'Superior Suite',
                                      'Deluxe Ocean View',
                                      'Royal Suite',
                                    ].map((r) {
                                      return DropdownMenuItem(
                                        value: r,
                                        child: Text(r, style: const TextStyle(fontSize: 12)),
                                      );
                                    }).toList(),
                                    onChanged: (val) {
                                      if (val != null) setModalState(() => selectedRoom = val);
                                    },
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _buildFormLabel('Booking Dates (Calendar)'),
                              const SizedBox(height: 6),
                              GestureDetector(
                                onTap: () async {
                                  await _selectDateRange(context, datesCtrl);
                                  setModalState(() {});
                                },
                                child: AbsorbPointer(
                                  child: _buildFormField(
                                    datesCtrl,
                                    suffixIcon: const Icon(
                                      Icons.calendar_today_outlined,
                                      size: 18,
                                      color: AppColors.primaryNavy,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),

                    // Price & Status Row
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _buildFormLabel('Total Amount (₹)'),
                              const SizedBox(height: 6),
                              _buildFormField(amountCtrl, keyboardType: TextInputType.number),
                            ],
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _buildFormLabel('Status'),
                              const SizedBox(height: 6),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 12),
                                decoration: BoxDecoration(
                                  color: AppColors.inputBackground,
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: DropdownButtonHideUnderline(
                                  child: DropdownButton<String>(
                                    value: selectedStatus,
                                    isExpanded: true,
                                    items: ['Confirmed', 'Pending', 'Cancelled'].map((s) {
                                      return DropdownMenuItem(
                                        value: s,
                                        child: Text(s, style: const TextStyle(fontSize: 13)),
                                      );
                                    }).toList(),
                                    onChanged: (val) {
                                      if (val != null) setModalState(() => selectedStatus = val);
                                    },
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),

                    // Submit Button
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        onPressed: () {
                          if (nameCtrl.text.trim().isEmpty) return;

                          final newBooking = BookingModel(
                            id: '#BK10${125 + _allBookings.length}',
                            guestName: nameCtrl.text.trim(),
                            guestEmail: emailCtrl.text.trim().isEmpty
                                ? 'guest@example.com'
                                : emailCtrl.text.trim(),
                            hotelName: selectedHotel,
                            roomType: selectedRoom,
                            dates: datesCtrl.text.trim(),
                            status: selectedStatus,
                            amount: double.tryParse(amountCtrl.text.trim()) ?? 3500,
                          );

                          setState(() {
                            _allBookings.insert(0, newBooking);
                          });

                          Navigator.pop(context);
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text('Booking ${newBooking.id} created successfully!'),
                              backgroundColor: AppColors.primaryNavy,
                            ),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.primaryNavy,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                        child: const Text(
                          'CREATE BOOKING',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.0,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  // Show Edit Booking Sheet with Calendar Date Picker
  void _openEditBookingForm(BookingModel booking) {
    final nameCtrl = TextEditingController(text: booking.guestName);
    final emailCtrl = TextEditingController(text: booking.guestEmail);
    final amountCtrl = TextEditingController(text: booking.amount.toStringAsFixed(0));
    final datesCtrl = TextEditingController(text: booking.dates);

    String selectedHotel = booking.hotelName;
    String selectedStatus = booking.status;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Container(
              padding: EdgeInsets.only(
                top: 20,
                left: 20,
                right: 20,
                bottom: MediaQuery.of(context).viewInsets.bottom + 20,
              ),
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
              ),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Container(
                        width: 40,
                        height: 4,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade300,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Edit Booking (${booking.id})',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: AppColors.primaryDark,
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.close),
                          onPressed: () => Navigator.pop(context),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),

                    // Guest Name
                    _buildFormLabel('Guest Full Name'),
                    const SizedBox(height: 6),
                    _buildFormField(nameCtrl),
                    const SizedBox(height: 14),

                    // Email Address
                    _buildFormLabel('Guest Email'),
                    const SizedBox(height: 6),
                    _buildFormField(emailCtrl),
                    const SizedBox(height: 14),

                    // Hotel Selection Dropdown
                    _buildFormLabel('Hotel'),
                    const SizedBox(height: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                      decoration: BoxDecoration(
                        color: AppColors.inputBackground,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          value: ['Le Parisien Luxe', 'Azure Beach Resort', 'The Azure Retreat', 'Summit Spire Lodge', 'Oasis Obscura'].contains(selectedHotel) ? selectedHotel : 'Le Parisien Luxe',
                          isExpanded: true,
                          items: [
                            'Le Parisien Luxe',
                            'Azure Beach Resort',
                            'The Azure Retreat',
                            'Summit Spire Lodge',
                            'Oasis Obscura',
                          ].map((h) {
                            return DropdownMenuItem(
                              value: h,
                              child: Text(h, style: const TextStyle(fontSize: 14)),
                            );
                          }).toList(),
                          onChanged: (val) {
                            if (val != null) setModalState(() => selectedHotel = val);
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),

                    // Dates & Amount
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _buildFormLabel('Booking Dates (Calendar)'),
                              const SizedBox(height: 6),
                              GestureDetector(
                                onTap: () async {
                                  await _selectDateRange(context, datesCtrl);
                                  setModalState(() {});
                                },
                                child: AbsorbPointer(
                                  child: _buildFormField(
                                    datesCtrl,
                                    suffixIcon: const Icon(
                                      Icons.calendar_today_outlined,
                                      size: 18,
                                      color: AppColors.primaryNavy,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _buildFormLabel('Amount (₹)'),
                              const SizedBox(height: 6),
                              _buildFormField(amountCtrl, keyboardType: TextInputType.number),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),

                    // Status Dropdown
                    _buildFormLabel('Status'),
                    const SizedBox(height: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                      decoration: BoxDecoration(
                        color: AppColors.inputBackground,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          value: selectedStatus,
                          isExpanded: true,
                          items: ['Confirmed', 'Pending', 'Cancelled'].map((s) {
                            return DropdownMenuItem(
                              value: s,
                              child: Text(s, style: const TextStyle(fontSize: 14)),
                            );
                          }).toList(),
                          onChanged: (val) {
                            if (val != null) setModalState(() => selectedStatus = val);
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),

                    // Save Changes Button
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        onPressed: () {
                          setState(() {
                            booking.guestName = nameCtrl.text.trim();
                            booking.guestEmail = emailCtrl.text.trim();
                            booking.hotelName = selectedHotel;
                            booking.dates = datesCtrl.text.trim();
                            booking.status = selectedStatus;
                            booking.amount = double.tryParse(amountCtrl.text.trim()) ?? booking.amount;
                          });

                          Navigator.pop(context);
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text('Booking ${booking.id} updated!'),
                              backgroundColor: AppColors.primaryNavy,
                            ),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.primaryNavy,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                        child: const Text(
                          'SAVE CHANGES',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.0,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  // Show Filter Sheet
  void _openFilterSheet() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: Colors.grey.shade300,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Filter Bookings',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: AppColors.primaryDark,
                        ),
                      ),
                      TextButton(
                        onPressed: () {
                          setState(() => _filterStatus = 'All');
                          Navigator.pop(context);
                        },
                        child: const Text('Reset All',
                            style: TextStyle(color: AppColors.textSecondary)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'STATUS',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      color: AppColors.textSecondary,
                      letterSpacing: 1.0,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 10,
                    children: ['All', 'Confirmed', 'Pending', 'Cancelled'].map((st) {
                      final bool isSelected = _filterStatus == st;
                      return ChoiceChip(
                        label: Text(st),
                        selected: isSelected,
                        selectedColor: AppColors.primaryNavy,
                        labelStyle: TextStyle(
                          color: isSelected ? Colors.white : AppColors.textPrimary,
                          fontWeight: FontWeight.bold,
                        ),
                        onSelected: (val) {
                          setState(() {
                            _filterStatus = st;
                          });
                          setModalState(() {});
                        },
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: ElevatedButton(
                      onPressed: () => Navigator.pop(context),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primaryNavy,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: const Text(
                        'APPLY FILTERS',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  // Show Booking Details Dialog
  void _openBookingDetails(BookingModel booking) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Booking ${booking.id}',
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: AppColors.primaryDark,
                ),
              ),
              _buildStatusBadge(booking.status),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Divider(),
              const SizedBox(height: 8),
              _buildDetailRow('Guest Name', booking.guestName),
              _buildDetailRow('Email', booking.guestEmail),
              _buildDetailRow('Hotel', booking.hotelName),
              _buildDetailRow('Room Type', booking.roomType),
              _buildDetailRow('Dates', booking.dates),
              _buildDetailRow('Total Paid', '₹${booking.amount.toStringAsFixed(2)}'),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Close'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                _openEditBookingForm(booking);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryNavy,
              ),
              child: const Text('Edit Booking', style: TextStyle(color: Colors.white)),
            ),
          ],
        );
      },
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: AppColors.textPrimary),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 12.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 2x2 Responsive Compact Grid for Metric Cards (Matching Original Figma Design)
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 1.35,
                children: [
                  _buildCompactMetricCard(
                    icon: Icons.account_balance_wallet_outlined,
                    iconBgColor: AppColors.primaryNavy,
                    iconColor: Colors.white,
                    label: 'Total Revenue',
                    value: '₹145,500',
                  ),
                  _buildCompactMetricCard(
                    icon: Icons.confirmation_number_outlined,
                    iconBgColor: const Color(0xFF38B6FF),
                    iconColor: AppColors.primaryNavy,
                    label: 'Total Bookings',
                    value: '${1230 + _allBookings.length - 4}',
                  ),
                  _buildCompactMetricCard(
                    icon: Icons.group_outlined,
                    iconBgColor: const Color(0xFFFFD180),
                    iconColor: AppColors.primaryNavy,
                    label: 'Active Users',
                    value: '980',
                  ),
                  _buildCompactMetricCard(
                    icon: Icons.hotel_outlined,
                    iconBgColor: const Color(0xFFFF8A80),
                    iconColor: AppColors.primaryNavy,
                    label: 'Occupancy Rate',
                    value: '85%',
                  ),
                ],
              ),
              const SizedBox(height: 20),

              // Admin Actions Card
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.borderLight),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.02),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Admin Actions',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: AppColors.primaryDark,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.network(
                            'https://images.unsplash.com/photo-1540541338287-41700207dee6?q=80&w=200&auto=format&fit=crop',
                            width: 50,
                            height: 50,
                            fit: BoxFit.cover,
                            errorBuilder: (_, _, _) => Container(
                              width: 50,
                              height: 50,
                              color: Colors.grey.shade300,
                            ),
                          ),
                        ),
                        const SizedBox(width: 14),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              'Booking Request',
                              style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                                color: AppColors.primaryDark,
                              ),
                            ),
                            SizedBox(height: 2),
                            Text(
                              '2 Nights • Superior Room',
                              style: TextStyle(
                                fontSize: 13,
                                color: AppColors.textSecondary,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 18),
                    Row(
                      children: [
                        Expanded(
                          child: SizedBox(
                            height: 46,
                            child: ElevatedButton(
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => const AdminHotelsScreen(),
                                  ),
                                );
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: AppColors.primaryNavy,
                                elevation: 0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10),
                                ),
                              ),
                              child: const Text(
                                'Add New Hotel',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        SizedBox(
                          height: 46,
                          child: OutlinedButton.icon(
                            onPressed: _openNewBookingForm,
                            style: OutlinedButton.styleFrom(
                              side: const BorderSide(color: AppColors.primaryNavy),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                            icon: const Icon(Icons.add, size: 18, color: AppColors.primaryNavy),
                            label: const Text(
                              'New Booking',
                              style: TextStyle(
                                color: AppColors.primaryNavy,
                                fontSize: 13,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // Recent Bookings Card with Horizontal Slide Table (NO Overflow Error)
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.borderLight),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.02),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                clipBehavior: Clip.antiAlias,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Header Row
                    Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: const [
                              Text(
                                'Recent\nBookings',
                                style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  color: AppColors.primaryDark,
                                  height: 1.15,
                                ),
                              ),
                            ],
                          ),
                          OutlinedButton.icon(
                            onPressed: _openFilterSheet,
                            style: OutlinedButton.styleFrom(
                              side: const BorderSide(color: AppColors.borderLight),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 14, vertical: 8),
                            ),
                            icon: const Icon(Icons.filter_list,
                                size: 16, color: AppColors.primaryDark),
                            label: Text(
                              _filterStatus == 'All'
                                  ? 'Filter'
                                  : 'Filter: $_filterStatus',
                              style: const TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.bold,
                                color: AppColors.primaryDark,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    // Horizontally Scrollable Table Container (Generous 520px width)
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: SizedBox(
                        width: 480,
                        child: Column(
                          children: [
                            // Table Header Bar
                            Container(
                              color: const Color(0xFFF1F5F9),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 16, vertical: 12),
                              child: Row(
                                children: const [
                                  SizedBox(
                                    width: 140,
                                    child: Text(
                                      'Guest & Hotel',
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: AppColors.textSecondary,
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    width: 90,
                                    child: Text(
                                      'Dates',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: AppColors.textSecondary,
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    width: 100,
                                    child: Text(
                                      'Status',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: AppColors.textSecondary,
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    width: 100,
                                    child: Text(
                                      'Actions',
                                      textAlign: TextAlign.right,
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: AppColors.textSecondary,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const Divider(height: 1, color: AppColors.borderLight),

                            // Table Rows
                            if (_filteredBookings.isEmpty)
                              const Padding(
                                padding: EdgeInsets.all(24.0),
                                child: Center(
                                  child: Text(
                                    'No bookings found for selected filter.',
                                    style: TextStyle(color: AppColors.textSecondary),
                                  ),
                                ),
                              )
                            else
                              ListView.separated(
                                shrinkWrap: true,
                                physics: const NeverScrollableScrollPhysics(),
                                itemCount: _filteredBookings.length,
                                separatorBuilder: (_, _) => const Divider(
                                    height: 1, color: AppColors.borderLight),
                                itemBuilder: (context, index) {
                                  final booking = _filteredBookings[index];
                                  return _buildBookingRow(booking);
                                },
                              ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCompactMetricCard({
    required IconData icon,
    required Color iconBgColor,
    required Color iconColor,
    required String label,
    required String value,
  }) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.borderLight),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: iconBgColor,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: iconColor, size: 18),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: const TextStyle(
              fontSize: 12,
              color: AppColors.textSecondary,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            value,
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: AppColors.primaryDark,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBookingRow(BookingModel booking) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Guest & Hotel Info
          SizedBox(
            width: 140,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  booking.guestName,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    color: AppColors.primaryDark,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  booking.hotelName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 11,
                    color: AppColors.textSecondary,
                  ),
                ),
                Text(
                  booking.id,
                  style: const TextStyle(
                    fontSize: 10,
                    color: AppColors.textSecondary,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),

          // Dates Column
          SizedBox(
            width: 90,
            child: Text(
              _formatDateDisplay(booking.dates),
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: AppColors.primaryDark,
                height: 1.2,
              ),
            ),
          ),

          // Status Badge
          SizedBox(
            width: 100,
            child: Center(
              child: _buildStatusBadge(booking.status),
            ),
          ),

          // Actions Column
          SizedBox(
            width: 100,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                // Edit Pencil Button
                IconButton(
                  icon: const Icon(Icons.edit_outlined,
                      size: 18, color: AppColors.primaryNavy),
                  constraints: const BoxConstraints(),
                  padding: const EdgeInsets.all(4),
                  onPressed: () => _openEditBookingForm(booking),
                  tooltip: 'Edit Booking',
                ),
                const SizedBox(width: 4),

                // Three Dots Options Popup Menu
                PopupMenuButton<String>(
                  icon: const Icon(Icons.more_vert,
                      size: 18, color: AppColors.textSecondary),
                  constraints: const BoxConstraints(),
                  padding: const EdgeInsets.all(4),
                  onSelected: (action) {
                    if (action == 'view') {
                      _openBookingDetails(booking);
                    } else if (action == 'edit') {
                      _openEditBookingForm(booking);
                    } else if (action == 'confirm') {
                      setState(() => booking.status = 'Confirmed');
                    } else if (action == 'cancel') {
                      setState(() => booking.status = 'Cancelled');
                    } else if (action == 'delete') {
                      setState(() {
                        _allBookings.removeWhere((b) => b.id == booking.id);
                      });
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Booking ${booking.id} removed.')),
                      );
                    }
                  },
                  itemBuilder: (context) => [
                    const PopupMenuItem(
                      value: 'view',
                      child: Row(
                        children: [
                          Icon(Icons.visibility_outlined, size: 16),
                          SizedBox(width: 8),
                          Text('View Details'),
                        ],
                      ),
                    ),
                    const PopupMenuItem(
                      value: 'edit',
                      child: Row(
                        children: [
                          Icon(Icons.edit_outlined, size: 16),
                          SizedBox(width: 8),
                          Text('Edit Booking'),
                        ],
                      ),
                    ),
                    const PopupMenuItem(
                      value: 'confirm',
                      child: Row(
                        children: [
                          Icon(Icons.check_circle_outline, size: 16, color: Colors.green),
                          SizedBox(width: 8),
                          Text('Mark Confirmed'),
                        ],
                      ),
                    ),
                    const PopupMenuItem(
                      value: 'cancel',
                      child: Row(
                        children: [
                          Icon(Icons.cancel_outlined, size: 16, color: Colors.orange),
                          SizedBox(width: 8),
                          Text('Mark Cancelled'),
                        ],
                      ),
                    ),
                    const PopupMenuDivider(),
                    const PopupMenuItem(
                      value: 'delete',
                      child: Row(
                        children: [
                          Icon(Icons.delete_outline, size: 16, color: Colors.red),
                          SizedBox(width: 8),
                          Text('Delete Booking', style: TextStyle(color: Colors.red)),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _formatDateDisplay(String dateText) {
    // Converts "Oct 12-15, 2023" to formatted stacked text: "Oct\n12-15,\n2023"
    final parts = dateText.split(' ');
    if (parts.length >= 3) {
      return '${parts[0]}\n${parts[1]}\n${parts[2]}';
    } else if (parts.length == 2) {
      return '${parts[0]}\n${parts[1]}';
    }
    return dateText;
  }

  Widget _buildStatusBadge(String status) {
    Color bg;
    Color text;

    if (status == 'Confirmed') {
      bg = const Color(0xFFDCFCE7); // Light Green
      text = const Color(0xFF15803D); // Dark Green
    } else if (status == 'Pending') {
      bg = const Color(0xFFFEF3C7); // Light Yellow/Gold
      text = const Color(0xFFB45309); // Dark Gold
    } else {
      bg = const Color(0xFFFEE2E2); // Light Red
      text = const Color(0xFFB91C1C); // Dark Red
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        status,
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.bold,
          color: text,
        ),
      ),
    );
  }

  Widget _buildFormLabel(String label) {
    return Text(
      label,
      style: const TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.bold,
        color: AppColors.textSecondary,
      ),
    );
  }

  Widget _buildFormField(TextEditingController controller,
      {String? hint, TextInputType? keyboardType, Widget? suffixIcon}) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      style: const TextStyle(fontSize: 14, color: AppColors.textPrimary),
      decoration: InputDecoration(
        filled: true,
        fillColor: AppColors.inputBackground,
        hintText: hint,
        suffixIcon: suffixIcon,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide.none,
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      ),
    );
  }
}
